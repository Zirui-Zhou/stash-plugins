"use strict";
(() => {
  // plugins/mangaTools/src/languages.ts
  window.MangaTools = window.MangaTools || {};
  var NS = window.MangaTools;
  NS.LANGUAGES = {
    ja: { flag: "jp" },
    "zh-Hans": { flag: "cn" },
    "zh-Hant": { flag: "tw" },
    en: { flag: "gb" },
    ko: { flag: "kr" },
    es: { flag: "es" },
    fr: { flag: "fr" },
    de: { flag: "de" },
    it: { flag: "it" },
    pt: { flag: "pt" },
    ru: { flag: "ru" },
    th: { flag: "th" },
    vi: { flag: "vn" },
    id: { flag: "id" }
  };
  NS.FALLBACK_LOCALE = "en";
  var displayNamesCache = {};
  var collatorCache = {};
  function collatorFor(locale) {
    if (!(locale in collatorCache)) {
      try {
        collatorCache[locale] = new Intl.Collator(locale);
      } catch {
        collatorCache[locale] = new Intl.Collator(NS.FALLBACK_LOCALE);
      }
    }
    return collatorCache[locale];
  }
  function buildDisplayNames(ctor, locales) {
    try {
      return new ctor(locales, { type: "language" });
    } catch {
      return null;
    }
  }
  function displayNamesFor(locale) {
    if (!(locale in displayNamesCache)) {
      const ctor = Intl.DisplayNames;
      displayNamesCache[locale] = typeof ctor === "function" ? buildDisplayNames(ctor, [locale, NS.FALLBACK_LOCALE]) || buildDisplayNames(ctor, [NS.FALLBACK_LOCALE]) : null;
    }
    return displayNamesCache[locale];
  }
  NS.findCanonical = (code) => {
    if (!code) return "";
    const lower = String(code).trim().toLowerCase();
    if (lower === "") return "";
    const keys = Object.keys(NS.LANGUAGES);
    for (let i = 0; i < keys.length; i++) {
      if (keys[i].toLowerCase() === lower) return keys[i];
    }
    return "";
  };
  NS.normalize = (raw) => {
    if (raw === null || raw === void 0) return "";
    const s = String(raw).trim();
    if (s === "") return "";
    return NS.findCanonical(s) || s;
  };
  NS.name = (code, locale) => {
    const normalized = NS.normalize(code);
    const canonical = NS.findCanonical(normalized);
    if (!canonical) {
      return normalized;
    }
    const names = displayNamesFor(locale || NS.FALLBACK_LOCALE);
    if (!names) return canonical;
    return names.of(canonical) || canonical;
  };
  NS.describe = (raw, locale) => {
    const code = NS.normalize(raw);
    if (code === "") return null;
    const canonical = NS.findCanonical(code);
    if (canonical) {
      return {
        code: canonical,
        flag: NS.LANGUAGES[canonical].flag,
        name: NS.name(canonical, locale),
        known: true
      };
    }
    return { code, flag: null, name: code, known: false };
  };
  NS.languageOptions = (locale) => {
    const uiLocale = locale || NS.FALLBACK_LOCALE;
    const collator = collatorFor(uiLocale);
    return Object.keys(NS.LANGUAGES).map((code) => ({
      value: code,
      label: NS.name(code, uiLocale),
      flag: NS.LANGUAGES[code].flag
    })).sort((a, b) => collator.compare(a.label, b.label));
  };
  NS.enabledLanguages = null;
  NS.parseEnabledLanguages = (raw) => {
    if (raw === null || raw === void 0) return null;
    const s = String(raw).trim();
    if (s === "") return null;
    const out = /* @__PURE__ */ new Set();
    s.split(",").forEach((piece) => {
      const canonical = NS.findCanonical(piece.trim());
      if (canonical) out.add(canonical);
    });
    return out.size ? out : null;
  };
  NS.serializeEnabledLanguages = (codes) => Array.from(codes).sort().join(",");
  NS.showFlags = true;
  NS.showCoverBadge = true;
  NS.parseFlag = (raw, fallback) => {
    if (raw === null || raw === void 0 || raw === "") return fallback;
    if (typeof raw === "boolean") return raw;
    const s = String(raw).trim().toLowerCase();
    if (s === "false" || s === "0" || s === "no" || s === "off") return false;
    if (s === "true" || s === "1" || s === "yes" || s === "on") return true;
    return fallback;
  };

  // plugins/mangaTools/src/fields.ts
  NS.FIELD_NAME = "plugin.mangaTools.language";
  NS.CENSORSHIP_FIELD_NAME = "plugin.mangaTools.censorship";
  NS.CENSORSHIP_VALUES = ["censored", "uncensored"];
  NS.normalizeCensorship = (raw) => {
    if (raw === null || raw === void 0) return "";
    const s = String(raw).trim().toLowerCase();
    if (s === "") return "";
    const values = NS.CENSORSHIP_VALUES;
    for (let i = 0; i < values.length; i++) {
      if (values[i] === s) return values[i];
    }
    return "";
  };
  NS.pickField = (customFields, name) => {
    if (!customFields || typeof customFields !== "object") return "";
    const map = customFields;
    const key = name.toLowerCase();
    const keys = Object.keys(map);
    for (let i = 0; i < keys.length; i++) {
      if (keys[i].toLowerCase() === key) {
        const v = map[keys[i]];
        if (v === null || v === void 0) return "";
        return String(v);
      }
    }
    return "";
  };
  NS.setField = (customFields, name, value) => {
    const next = Object.assign({}, customFields || {});
    const key = name.toLowerCase();
    Object.keys(next).forEach((k) => {
      if (k.toLowerCase() === key) delete next[k];
    });
    if (value) next[name] = value;
    return next;
  };

  // plugins/mangaTools/src/messages/en.json
  var en_default = {
    "mangaTools.select.placeholder": "Select language\u2026",
    "mangaTools.settings.enabledLanguages.heading": "Enabled languages",
    "mangaTools.settings.enabledLanguages.description": "Only these languages appear in the edit-page dropdown. Display (badge and detail row) is unaffected. Leave empty to show every language.",
    "mangaTools.settings.enabledLanguages.placeholder": "All languages",
    "mangaTools.settings.showFlags.heading": "Show flags",
    "mangaTools.settings.showFlags.description": "Draw the flag beside the language name. Turn this off to show the name on its own.",
    "mangaTools.settings.showCoverBadge.heading": "Show the language on gallery covers",
    "mangaTools.settings.showCoverBadge.description": "The badge in the bottom-right of a gallery's cover. With flags turned off it shows the language name instead of a flag.",
    "mangaTools.censorship.censored": "Censored",
    "mangaTools.censorship.uncensored": "Uncensored",
    "mangaTools.censorship.unset": "Not marked",
    "mangaTools.censorship.markCensored": "Mark as censored",
    "mangaTools.censorship.markUncensored": "Mark as uncensored",
    "mangaTools.censorship.clear": "Clear the censorship mark"
  };

  // plugins/mangaTools/src/messages/zh-Hans.json
  var zh_Hans_default = {
    "mangaTools.select.placeholder": "\u9009\u62E9\u8BED\u8A00\u2026",
    "mangaTools.settings.enabledLanguages.heading": "\u542F\u7528\u7684\u8BED\u8A00",
    "mangaTools.settings.enabledLanguages.description": "\u53EA\u6709\u8FD9\u4E9B\u8BED\u8A00\u4F1A\u51FA\u73B0\u5728\u7F16\u8F91\u9875\u7684\u4E0B\u62C9\u6846\u91CC\u3002\u663E\u793A\u65B9\u5F0F\uFF08\u5C01\u9762\u5FBD\u7AE0\u548C\u8BE6\u60C5\u9875\u90A3\u4E00\u884C\uFF09\u4E0D\u53D7\u5F71\u54CD\u3002\u7559\u7A7A\u8868\u793A\u663E\u793A\u5168\u90E8\u8BED\u8A00\u3002",
    "mangaTools.settings.enabledLanguages.placeholder": "\u5168\u90E8\u8BED\u8A00",
    "mangaTools.settings.showFlags.heading": "\u663E\u793A\u56FD\u65D7",
    "mangaTools.settings.showFlags.description": "\u5728\u8BED\u8A00\u540D\u79F0\u65C1\u753B\u51FA\u56FD\u65D7\u3002\u5173\u6389\u540E\u53EA\u663E\u793A\u540D\u79F0\u3002",
    "mangaTools.settings.showCoverBadge.heading": "\u5728\u5C01\u9762\u663E\u793A\u8BED\u8A00",
    "mangaTools.settings.showCoverBadge.description": "\u753B\u5ECA\u5C01\u9762\u53F3\u4E0B\u89D2\u7684\u5FBD\u7AE0\u3002\u5173\u6389\u56FD\u65D7\u65F6\u663E\u793A\u8BED\u8A00\u540D\u79F0\u800C\u4E0D\u662F\u56FD\u65D7\u3002",
    "mangaTools.censorship.censored": "\u6709\u4FEE\u6B63",
    "mangaTools.censorship.uncensored": "\u65E0\u4FEE\u6B63",
    "mangaTools.censorship.unset": "\u672A\u6807\u6CE8",
    "mangaTools.censorship.markCensored": "\u6807\u4E3A\u6709\u4FEE\u6B63",
    "mangaTools.censorship.markUncensored": "\u6807\u4E3A\u65E0\u4FEE\u6B63",
    "mangaTools.censorship.clear": "\u6E05\u9664\u4FEE\u6B63\u6807\u6CE8"
  };

  // plugins/mangaTools/src/messages/zh-Hant.json
  var zh_Hant_default = {
    "mangaTools.select.placeholder": "\u9078\u64C7\u8A9E\u8A00\u2026",
    "mangaTools.settings.enabledLanguages.heading": "\u555F\u7528\u7684\u8A9E\u8A00",
    "mangaTools.settings.enabledLanguages.description": "\u53EA\u6709\u9019\u4E9B\u8A9E\u8A00\u6703\u51FA\u73FE\u5728\u7DE8\u8F2F\u9801\u7684\u4E0B\u62C9\u9078\u55AE\u88E1\u3002\u986F\u793A\u65B9\u5F0F\uFF08\u5C01\u9762\u5FBD\u7AE0\u548C\u8A73\u7D30\u9801\u90A3\u4E00\u884C\uFF09\u4E0D\u53D7\u5F71\u97FF\u3002\u7559\u7A7A\u8868\u793A\u986F\u793A\u5168\u90E8\u8A9E\u8A00\u3002",
    "mangaTools.settings.enabledLanguages.placeholder": "\u5168\u90E8\u8A9E\u8A00",
    "mangaTools.settings.showFlags.heading": "\u986F\u793A\u570B\u65D7",
    "mangaTools.settings.showFlags.description": "\u5728\u8A9E\u8A00\u540D\u7A31\u65C1\u756B\u51FA\u570B\u65D7\u3002\u95DC\u6389\u5F8C\u53EA\u986F\u793A\u540D\u7A31\u3002",
    "mangaTools.settings.showCoverBadge.heading": "\u5728\u5C01\u9762\u986F\u793A\u8A9E\u8A00",
    "mangaTools.settings.showCoverBadge.description": "\u756B\u5ECA\u5C01\u9762\u53F3\u4E0B\u89D2\u7684\u5FBD\u7AE0\u3002\u95DC\u6389\u570B\u65D7\u6642\u986F\u793A\u8A9E\u8A00\u540D\u7A31\u800C\u4E0D\u662F\u570B\u65D7\u3002",
    "mangaTools.censorship.censored": "\u6709\u4FEE\u6B63",
    "mangaTools.censorship.uncensored": "\u7121\u4FEE\u6B63",
    "mangaTools.censorship.unset": "\u672A\u6A19\u8A3B",
    "mangaTools.censorship.markCensored": "\u6A19\u70BA\u6709\u4FEE\u6B63",
    "mangaTools.censorship.markUncensored": "\u6A19\u70BA\u7121\u4FEE\u6B63",
    "mangaTools.censorship.clear": "\u6E05\u9664\u4FEE\u6B63\u6A19\u8A3B"
  };

  // plugins/mangaTools/src/i18n.ts
  var CATALOGS = {
    en: en_default,
    "zh-Hans": zh_Hans_default,
    "zh-Hant": zh_Hant_default
  };
  var ALIASES = { zh: "zh-Hans" };
  function catalogs() {
    return CATALOGS;
  }
  function catalogFor(locale) {
    const parts = String(locale || "").replace("_", "-").split("-");
    while (parts.length > 0) {
      const tag = parts.join("-");
      const catalog = CATALOGS[ALIASES[tag] || tag];
      if (catalog) return catalog;
      parts.pop();
    }
    return CATALOGS.en;
  }
  function t(intl, id) {
    var _a, _b;
    return (_b = (_a = catalogFor(intl.locale)[id]) != null ? _a : CATALOGS.en[id]) != null ? _b : id;
  }
  NS.t = t;
  NS.catalogFor = catalogFor;
  NS.catalogs = catalogs;

  // plugins/mangaTools/src/plugin-api.ts
  function requirePluginApi() {
    const api = window.PluginApi;
    if (!api) {
      throw new Error(
        "[mangaTools] window.PluginApi is missing \u2014 the plugin cannot load"
      );
    }
    return api;
  }

  // plugins/mangaTools/src/language-filter.tsx
  var PluginApi = requirePluginApi();
  var React = PluginApi.React;
  var CUSTOM_FIELDS_TYPE = "custom_fields";
  var LANGUAGE_TYPE = "language";
  var EMPTY_SELECTION = {
    modifier: "",
    included: [],
    excluded: []
  };
  function registerLanguageCriterionOption(filter) {
    var _a;
    const options = (_a = filter == null ? void 0 : filter.options) == null ? void 0 : _a.criterionOptions;
    if (!options) return;
    let found = null;
    for (let i = 0; i < options.length; i++) {
      if (options[i].type === LANGUAGE_TYPE) return;
      if (options[i].type === CUSTOM_FIELDS_TYPE) found = options[i];
    }
    if (!found) return;
    const customFieldsOption = found;
    const option = {
      type: LANGUAGE_TYPE,
      messageID: "config.ui.language.heading",
      makeCriterion: () => {
        const criterion = customFieldsOption.makeCriterion();
        criterion.criterionOption = option;
        criterion.value = [];
        criterion.toQueryParams = function() {
          return { type: CUSTOM_FIELDS_TYPE, value: this.value };
        };
        return criterion;
      }
    };
    options.push(option);
  }
  function customFieldsCriterion(filter) {
    var _a;
    const criteria = (filter == null ? void 0 : filter.criteria) || [];
    for (let i = 0; i < criteria.length; i++) {
      const option = (_a = criteria[i]) == null ? void 0 : _a.criterionOption;
      if (!option) continue;
      if (option.type === CUSTOM_FIELDS_TYPE || option.type === LANGUAGE_TYPE) {
        return criteria[i];
      }
    }
    return null;
  }
  function isLanguageCondition(condition) {
    return !!condition && String(condition.field).toLowerCase() === NS.FIELD_NAME.toLowerCase();
  }
  function conditionValues(condition) {
    const values = condition.value || [];
    return values.map((v) => String(v));
  }
  function isLanguageCriterion(criterion) {
    const conditions = (criterion == null ? void 0 : criterion.value) || [];
    if (!conditions.length) return false;
    for (let i = 0; i < conditions.length; i++) {
      if (!isLanguageCondition(conditions[i])) return false;
    }
    return true;
  }
  function languageCriterionOf(filter) {
    const criterion = customFieldsCriterion(filter);
    return criterion && isLanguageCriterion(criterion) ? criterion : null;
  }
  function adoptLanguageCriterion(filter) {
    var _a;
    const criterion = languageCriterionOf(filter);
    if (!criterion) return;
    if (criterion.criterionOption && criterion.criterionOption.type === LANGUAGE_TYPE) {
      return;
    }
    const options = ((_a = filter.options) == null ? void 0 : _a.criterionOptions) || [];
    let option = null;
    for (let i = 0; i < options.length; i++) {
      if (options[i].type === LANGUAGE_TYPE) option = options[i];
    }
    if (!option) return;
    criterion.criterionOption = option;
    criterion.toQueryParams = function() {
      return { type: CUSTOM_FIELDS_TYPE, value: this.value };
    };
  }
  function readLanguageFilter(filter) {
    const criterion = customFieldsCriterion(filter);
    if (!(criterion == null ? void 0 : criterion.value)) return EMPTY_SELECTION;
    const selection = {
      modifier: "",
      included: [],
      excluded: []
    };
    criterion.value.forEach((condition) => {
      if (!isLanguageCondition(condition)) return;
      if (condition.modifier === "NOT_NULL") selection.modifier = "any";
      else if (condition.modifier === "IS_NULL") selection.modifier = "none";
      else if (condition.modifier === "EQUALS") {
        selection.included = conditionValues(condition);
      } else if (condition.modifier === "NOT_EQUALS") {
        selection.excluded = conditionValues(condition);
      }
    });
    return selection;
  }
  function toggleIncluded(selection, code) {
    const already = selection.included.indexOf(code) !== -1;
    return {
      modifier: "",
      included: already ? selection.included.filter((c) => c !== code) : selection.included.concat([code]),
      // A language is included or excluded, never both: EQUALS and NOT_EQUALS for
      // one value is a contradiction and matches nothing.
      excluded: selection.excluded.filter((c) => c !== code)
    };
  }
  function toggleExcluded(selection, code) {
    const already = selection.excluded.indexOf(code) !== -1;
    return {
      modifier: "",
      included: selection.included.filter((c) => c !== code),
      excluded: already ? selection.excluded.filter((c) => c !== code) : selection.excluded.concat([code])
    };
  }
  function withModifier(_selection, modifier) {
    return { modifier, included: [], excluded: [] };
  }
  function withoutModifier(selection) {
    return {
      modifier: "",
      included: selection.included.slice(),
      excluded: selection.excluded.slice()
    };
  }
  function isEmptySelection(selection) {
    return !selection.modifier && !selection.included.length && !selection.excluded.length;
  }
  function sameSelection(a, b) {
    return a.modifier === b.modifier && sameCodes(a.included, b.included) && sameCodes(a.excluded, b.excluded);
  }
  function sameCodes(a, b) {
    if (a.length !== b.length) return false;
    const x = a.slice().sort();
    const y = b.slice().sort();
    for (let i = 0; i < x.length; i++) {
      if (x[i] !== y[i]) return false;
    }
    return true;
  }
  function modifierWord(intl, modifier) {
    if (modifier === "IS_NULL") {
      return message(intl, "criterion_modifier.is_null", "is null");
    }
    if (modifier === "NOT_NULL") {
      return message(intl, "criterion_modifier.not_null", "is not null");
    }
    if (modifier === "NOT_EQUALS") {
      return message(intl, "criterion_modifier.not_equals", "is not");
    }
    if (modifier === "EQUALS") {
      return message(intl, "criterion_modifier.equals", "is");
    }
    return null;
  }
  function conditionLabel(intl, condition) {
    const word = modifierWord(intl, condition.modifier);
    if (word === null) return null;
    return intl.formatMessage(
      { id: "criterion_modifier.format_string" },
      {
        criterion: fieldLabel(intl),
        modifierString: word,
        valueString: conditionValues(condition).map((code) => NS.name(code, intl.locale)).join(", ")
      }
    );
  }
  function tagLabels(intl, criterion) {
    const conditions = criterion.value || [];
    const labels = [];
    for (let i = 0; i < conditions.length; i++) {
      const label = conditionLabel(intl, conditions[i]);
      if (label === null) return null;
      labels.push(label);
    }
    return labels.length ? labels : null;
  }
  function selectionConditions(selection) {
    if (selection.modifier === "any") {
      return [{ field: NS.FIELD_NAME, modifier: "NOT_NULL" }];
    }
    if (selection.modifier === "none") {
      return [{ field: NS.FIELD_NAME, modifier: "IS_NULL" }];
    }
    const conditions = [];
    if (selection.included.length) {
      conditions.push({
        field: NS.FIELD_NAME,
        modifier: "EQUALS",
        value: selection.included.slice()
      });
    }
    if (selection.excluded.length) {
      conditions.push({
        field: NS.FIELD_NAME,
        modifier: "NOT_EQUALS",
        value: selection.excluded.slice()
      });
    }
    return conditions;
  }
  function languageFilterQuery(filter, selection) {
    var _a;
    if (!filter || typeof filter.clone !== "function") return null;
    const options = ((_a = filter.options) == null ? void 0 : _a.criterionOptions) || [];
    let option = null;
    for (let i = 0; i < options.length; i++) {
      if (options[i].type === CUSTOM_FIELDS_TYPE) option = options[i];
      if (options[i].type === LANGUAGE_TYPE) option = options[i];
    }
    if (!option) return null;
    const criterionOption = option;
    const next = filter.clone();
    let criterion = customFieldsCriterion(next);
    const kept = [];
    if (criterion == null ? void 0 : criterion.value) {
      for (let j = 0; j < criterion.value.length; j++) {
        if (!isLanguageCondition(criterion.value[j]))
          kept.push(criterion.value[j]);
      }
    }
    const conditions = kept.concat(selectionConditions(selection));
    if (!conditions.length) {
      next.criteria = (next.criteria || []).filter((c) => c !== criterion);
    } else {
      if (!criterion) {
        criterion = criterionOption.makeCriterion();
        next.criteria = (next.criteria || []).concat([criterion]);
      }
      criterion.value = conditions;
    }
    return next.makeQueryParameters();
  }
  function applyLanguage(filter, history, selection) {
    const search = languageFilterQuery(filter, selection);
    if (search === null) {
      console.error(
        "[mangaTools] this list has no custom-fields filter, so the language filter is unavailable"
      );
      return;
    }
    history.replace(Object.assign({}, history.location, { search }));
  }
  NS.toggleIncluded = toggleIncluded;
  NS.toggleExcluded = toggleExcluded;
  NS.withModifier = withModifier;
  NS.withoutModifier = withoutModifier;
  NS.isEmptySelection = isEmptySelection;
  NS.sameSelection = sameSelection;
  NS.conditionLabel = conditionLabel;
  NS.tagLabels = tagLabels;
  NS.readLanguageFilter = readLanguageFilter;
  NS.languageFilterQuery = languageFilterQuery;
  NS.registerLanguageCriterionOption = registerLanguageCriterionOption;
  NS.adoptLanguageCriterion = adoptLanguageCriterion;
  NS.relabelTags = relabelTags;
  NS.manageDialogTags = manageDialogTags;
  NS.ownTagLabels = ownTagLabels;
  NS.clickedTagRemove = clickedTagRemove;
  function fieldLabel(intl) {
    return intl.formatMessage({
      id: "config.ui.language.heading",
      defaultMessage: "Language"
    });
  }
  function Flag(props) {
    return /* @__PURE__ */ React.createElement(
      "span",
      {
        className: "fi fi-" + props.flag + (props.className ? " " + props.className : "")
      }
    );
  }
  function message(intl, id, fallback) {
    return intl.formatMessage({ id, defaultMessage: fallback });
  }
  var SECTION_STATE_KEY = "mangaToolsLanguageOpen";
  function isTouchDevice() {
    return window.matchMedia("(pointer: coarse)").matches;
  }
  var FILTER_HOST_CLASS = "manga-tools-field-host";
  var filterHost = null;
  function visibleOptions(intl, selection) {
    return NS.languageOptions(intl.locale).filter(
      (o) => !NS.enabledLanguages || NS.enabledLanguages.has(o.value) || selection.included.indexOf(o.value) !== -1 || selection.excluded.indexOf(o.value) !== -1
    );
  }
  function selectableOptions(selection, options) {
    return selection.modifier ? [] : options;
  }
  function matchesQuery(option, query) {
    const needle = query.trim().toLowerCase();
    if (!needle) return true;
    return option.label.toLowerCase().indexOf(needle) !== -1 || option.value.toLowerCase().indexOf(needle) !== -1;
  }
  function flagOf(option) {
    return NS.showFlags ? option.flag : null;
  }
  function LanguageRow(props) {
    const Solid = PluginApi.libraries.FontAwesomeSolid || {};
    const Regular = PluginApi.libraries.FontAwesomeRegular || {};
    const Icon = PluginApi.components.Icon;
    const Bootstrap = PluginApi.libraries.Bootstrap;
    const intl = PluginApi.libraries.Intl.useIntl();
    const hover = React.useState(false);
    const hovered = hover[0];
    const setHovered = hover[1];
    const selected = props.state !== "candidate";
    const excluded = props.state === "excluded";
    const sidebar = props.variant === "sidebar";
    function setHover(next) {
      return () => {
        setHovered(next);
      };
    }
    const icon = !selected ? Solid.faPlus : hovered ? Regular.faTimesCircle || Solid.faTimesCircle : excluded ? Solid.faTimesCircle : Solid.faCheckCircle;
    const labelClass = excluded ? "excluded-object-label" : selected ? "selected-object-label" : "unselected-object-label";
    return /* @__PURE__ */ React.createElement(
      "li",
      {
        className: (selected ? "selected-object" : "unselected-object") + (props.modifier ? " modifier-object" : "")
      },
      /* @__PURE__ */ React.createElement(
        "a",
        {
          tabIndex: 0,
          onClick: props.onClick,
          onMouseEnter: setHover(true),
          onMouseLeave: setHover(false),
          onFocus: setHover(true),
          onBlur: setHover(false)
        },
        /* @__PURE__ */ React.createElement("div", { className: sidebar ? "label-group" : void 0 }, /* @__PURE__ */ React.createElement(
          Icon,
          {
            className: "fa-fw " + (excluded ? "exclude-icon" : "include-button"),
            icon
          }
        ), props.flag ? /* @__PURE__ */ React.createElement(Flag, { flag: props.flag }) : null, sidebar ? /* @__PURE__ */ React.createElement("span", { className: "TruncatedText inline " + labelClass }, props.label) : /* @__PURE__ */ React.createElement("span", { className: labelClass }, props.label)),
        !selected || !sidebar ? /* @__PURE__ */ React.createElement("div", null, props.canExclude && !selected && Bootstrap ? /* @__PURE__ */ React.createElement(
          Bootstrap.Button,
          {
            variant: "secondary",
            className: "minimal exclude-button",
            onClick: (e) => {
              e.stopPropagation();
              if (props.onExclude) props.onExclude();
            },
            onKeyDown: (e) => {
              e.stopPropagation();
            }
          },
          /* @__PURE__ */ React.createElement("span", { className: "exclude-button-text" }, sidebar ? "exclude" : message(intl, "actions.exclude_lowercase", "exclude")),
          /* @__PURE__ */ React.createElement(Icon, { className: "fa-fw exclude-icon", icon: Solid.faMinus })
        ) : null) : null
      )
    );
  }
  var TAG_SELECTOR = ".filter-tags .tag-item";
  var TAG_MARK = "data-manga-tools-language";
  var OWN_TAG_MARK = "data-manga-tools-own-tag";
  function isLanguageTag(tag) {
    const text = tag.firstChild;
    if ((text == null ? void 0 : text.nodeType) !== 3) return false;
    const value = String(text.nodeValue).trim();
    if (tag.getAttribute(TAG_MARK) === value) return true;
    const prefix = NS.FIELD_NAME.toLowerCase() + " ";
    return value.toLowerCase().indexOf(prefix) === 0;
  }
  function tagText(tag) {
    return tag.firstChild;
  }
  function listLanguageTags() {
    const all = document.querySelectorAll(TAG_SELECTOR);
    const ours = [];
    for (let i = 0; i < all.length; i++) {
      if (all[i].closest(".edit-filter-dialog")) continue;
      if (isLanguageTag(all[i])) ours.push(all[i]);
    }
    return ours;
  }
  function dialogLanguageTags() {
    const all = document.querySelectorAll(TAG_SELECTOR);
    const ours = [];
    for (let i = 0; i < all.length; i++) {
      if (!all[i].closest(".edit-filter-dialog")) continue;
      if (all[i].closest(".criterion-list")) continue;
      if (all[i].hasAttribute(OWN_TAG_MARK)) continue;
      if (isLanguageTag(all[i])) ours.push(all[i]);
    }
    return ours;
  }
  function writeTagLabels(tags, labels) {
    for (let i = 0; i < tags.length && i < labels.length; i++) {
      tagText(tags[i]).nodeValue = labels[i];
      tags[i].setAttribute(TAG_MARK, labels[i]);
    }
  }
  function relabelTags(labels) {
    writeTagLabels(listLanguageTags(), labels);
  }
  var DIALOG_HOST_CLASS = "manga-tools-dialog-host";
  function dialogEditorBox() {
    return document.querySelector(
      '.criterion-list [data-type="' + LANGUAGE_TYPE + '"] .criterion-editor'
    );
  }
  var dialogTagsFallback = null;
  function stashDialogTagsRow() {
    const content = document.querySelector(".edit-filter-dialog .dialog-content");
    if (!content) return null;
    const rows = content.querySelectorAll(".filter-tags");
    for (let i = 0; i < rows.length; i++) {
      if (rows[i] === dialogTagsFallback) continue;
      if (!rows[i].closest(".criterion-list")) return rows[i];
    }
    return null;
  }
  function dialogTagsRow() {
    const stash = stashDialogTagsRow();
    if (stash) {
      dropFallbackRow();
      return stash;
    }
    const content = document.querySelector(".edit-filter-dialog .dialog-content");
    if (!content) {
      dropFallbackRow();
      return null;
    }
    if (!dialogTagsFallback) {
      dialogTagsFallback = document.createElement("div");
      dialogTagsFallback.className = "wrap-tags filter-tags";
    }
    if (dialogTagsFallback.parentNode !== content) {
      content.appendChild(dialogTagsFallback);
    }
    return dialogTagsFallback;
  }
  function dropFallbackRow() {
    if (dialogTagsFallback == null ? void 0 : dialogTagsFallback.parentNode) {
      dialogTagsFallback.parentNode.removeChild(dialogTagsFallback);
    }
  }
  function manageDialogTags(labels) {
    const tags = dialogLanguageTags();
    for (let i = 0; i < tags.length; i++) {
      const label = i < labels.length ? labels[i] : null;
      const text = tagText(tags[i]);
      if (label !== null && text.nodeValue !== label) {
        text.nodeValue = label;
        tags[i].setAttribute(TAG_MARK, label);
      }
      const display = label === null ? "none" : "";
      if (tags[i].style.display !== display) tags[i].style.display = display;
    }
  }
  function ownTagLabels(labels) {
    return labels.slice(dialogLanguageTags().length);
  }
  function clickedTagRemove(target) {
    if (!target || typeof target.closest !== "function") return false;
    if (!target.closest(".edit-filter-dialog")) return false;
    if (!target.closest(".filter-tags .tag-item button")) return false;
    const tag = target.closest(".tag-item");
    return !!tag && !tag.closest(".criterion-list") && isLanguageTag(tag);
  }
  function LanguageTag(props) {
    const Solid = PluginApi.libraries.FontAwesomeSolid || {};
    const Icon = PluginApi.components.Icon;
    const Bootstrap = PluginApi.libraries.Bootstrap;
    return /* @__PURE__ */ React.createElement(
      "span",
      {
        className: "tag-item badge badge-secondary",
        "data-manga-tools-own-tag": ""
      },
      props.label,
      Bootstrap ? (
        // `variant` alone: adding the class names as well is how this came out
        // as `btn btn-secondary btn btn-secondary`.
        /* @__PURE__ */ React.createElement(Bootstrap.Button, { variant: "secondary", onClick: props.onRemove }, /* @__PURE__ */ React.createElement(Icon, { icon: Solid.faXmark || Solid.faTimes }))
      ) : null
    );
  }
  function dialogDomState() {
    const dialog = document.querySelector(".edit-filter-dialog");
    if (!dialog) return "";
    return (dialogEditorBox() ? "card " : "") + (stashDialogTagsRow() ? "tags" : "");
  }
  function DialogLanguageFilter(props) {
    const intl = PluginApi.libraries.Intl.useIntl();
    const history = PluginApi.libraries.ReactRouterDOM.useHistory();
    const bumpState = React.useState(0);
    const bump = bumpState[1];
    const applied = readLanguageFilter(props.filter);
    const choiceState = React.useState(applied);
    const choice = choiceState[0];
    const setChoice = choiceState[1];
    const queryState = React.useState("");
    const query = queryState[0];
    const setQuery = queryState[1];
    const searchRef = React.useRef(null);
    const applyPending = React.useRef(false);
    const dialogDom = React.useRef("");
    React.useEffect(() => {
      if (typeof MutationObserver !== "function") return;
      const observer = new MutationObserver(() => {
        const state = dialogDomState();
        if (state === dialogDom.current) return;
        dialogDom.current = state;
        bump((v) => v + 1);
      });
      observer.observe(document.body, { childList: true, subtree: true });
      return () => {
        observer.disconnect();
      };
    }, []);
    React.useEffect(() => {
      function onClick(event) {
        const clicked = event.target;
        if (!clicked || typeof clicked.closest !== "function") return;
        if (!clicked.closest(".edit-filter-dialog")) return;
        if (clicked.closest(".modal-footer button.btn-primary")) {
          applyPending.current = true;
          window.setTimeout(() => {
            if (!applyPending.current) return;
            applyPending.current = false;
            console.warn(
              "[mangaTools] Apply changed nothing in Stash's filter, so the language picked in the card was not applied. Pick it in the sidebar instead."
            );
          }, 2e3);
        }
        if (clicked.closest(".clear-all-button") || clicked.closest(
          '.criterion-list [data-type="' + LANGUAGE_TYPE + '"] .remove-criterion-button'
        ) || clickedTagRemove(clicked)) {
          setChoice(EMPTY_SELECTION);
          setQuery("");
        }
      }
      document.addEventListener("click", onClick, true);
      return () => {
        document.removeEventListener("click", onClick, true);
      };
    }, []);
    const lastModel = React.useRef(null);
    React.useEffect(() => {
      const model = props.filter;
      const previous = lastModel.current;
      lastModel.current = model;
      if (!applyPending.current) return;
      if (!previous || previous === model) return;
      applyPending.current = false;
      const unchanged = sameSelection(choice, readLanguageFilter(model));
      if (unchanged) return;
      const search = languageFilterQuery(model, choice);
      if (search === null) {
        console.error(
          "[mangaTools] this list has no custom-fields criterion, so the language filter could not be applied"
        );
        return;
      }
      history.replace(Object.assign({}, history.location, { search }));
    });
    const dialogTagLabels = isEmptySelection(choice) ? [] : tagLabels(intl, { value: selectionConditions(choice) }) || [];
    const ownTags = ownTagLabels(dialogTagLabels);
    const ownTagsRow = ownTags.length ? dialogTagsRow() : null;
    React.useLayoutEffect(() => {
      manageDialogTags(dialogTagLabels);
      if (!ownTagsRow) dropFallbackRow();
    });
    const sessionRef = React.useRef(0);
    const syncedRef = React.useRef(-1);
    React.useLayoutEffect(() => {
      if (!document.querySelector(".edit-filter-dialog")) {
        sessionRef.current += 1;
        syncedRef.current = -1;
        return;
      }
      if (syncedRef.current === sessionRef.current) return;
      syncedRef.current = sessionRef.current;
      const applied2 = readLanguageFilter(props.filter);
      setChoice(
        (previous) => sameSelection(previous, applied2) ? previous : applied2
      );
      setQuery("");
    });
    const options = visibleOptions(intl, choice);
    const selectable = selectableOptions(choice, options);
    const chosen = selectable.filter(
      (o) => choice.included.indexOf(o.value) !== -1
    );
    const excludedChosen = selectable.filter(
      (o) => choice.excluded.indexOf(o.value) !== -1
    );
    const candidates = selectable.filter(
      (o) => choice.included.indexOf(o.value) === -1 && choice.excluded.indexOf(o.value) === -1 && matchesQuery(o, query)
    );
    const showModifiers = isEmptySelection(choice);
    const box = dialogEditorBox();
    let host = null;
    if (box) {
      host = box.querySelector("." + DIALOG_HOST_CLASS);
      if (!host) {
        host = document.createElement("div");
        host.className = DIALOG_HOST_CLASS;
        box.insertBefore(host, box.firstChild);
      }
    }
    const list = /* @__PURE__ */ React.createElement("div", { className: "manga-tools-dialog-card" }, /* @__PURE__ */ React.createElement("div", { className: "selectable-filter" }, /* @__PURE__ */ React.createElement("div", { className: "clearable-input-group" }, /* @__PURE__ */ React.createElement(
      "input",
      {
        ref: searchRef,
        className: "clearable-text-field form-control",
        value: query,
        placeholder: message(intl, "actions.search", "Search") + "\u2026",
        onChange: (e) => {
          setQuery(e.target.value);
        },
        onKeyDown: (e) => {
          if (e.key === "Escape") {
            if (searchRef.current) searchRef.current.blur();
            return;
          }
          if (e.key !== "Enter" || candidates.length !== 1) return;
          setChoice(toggleIncluded(choice, candidates[0].value));
          setQuery("");
        }
      }
    )), /* @__PURE__ */ React.createElement("ul", null, choice.modifier ? /* @__PURE__ */ React.createElement(
      LanguageRow,
      {
        variant: "dialog",
        modifier: true,
        state: "included",
        label: choice.modifier === "any" ? message(intl, "criterion_modifier_values.any", "Any") : message(intl, "criterion_modifier_values.none", "None"),
        onClick: () => {
          setChoice(withoutModifier(choice));
        }
      }
    ) : null, chosen.map((o) => /* @__PURE__ */ React.createElement(
      LanguageRow,
      {
        key: "in-" + o.value,
        variant: "dialog",
        state: "included",
        label: o.label,
        flag: flagOf(o),
        onClick: () => {
          setChoice(toggleIncluded(choice, o.value));
        }
      }
    )), excludedChosen.map((o) => /* @__PURE__ */ React.createElement("li", { key: "ex-" + o.value, className: "excluded-object" }, /* @__PURE__ */ React.createElement(
      LanguageRow,
      {
        variant: "dialog",
        state: "excluded",
        label: o.label,
        flag: flagOf(o),
        onClick: () => {
          setChoice(toggleExcluded(choice, o.value));
        }
      }
    ))), showModifiers ? /* @__PURE__ */ React.createElement(
      LanguageRow,
      {
        variant: "dialog",
        modifier: true,
        state: "candidate",
        canExclude: false,
        label: message(intl, "criterion_modifier_values.any", "Any"),
        onClick: () => {
          setChoice(withModifier(choice, "any"));
        }
      }
    ) : null, showModifiers ? /* @__PURE__ */ React.createElement(
      LanguageRow,
      {
        variant: "dialog",
        modifier: true,
        state: "candidate",
        canExclude: false,
        label: message(intl, "criterion_modifier_values.none", "None"),
        onClick: () => {
          setChoice(withModifier(choice, "none"));
        }
      }
    ) : null, candidates.map((o) => /* @__PURE__ */ React.createElement(
      LanguageRow,
      {
        key: o.value,
        variant: "dialog",
        state: "candidate",
        label: o.label,
        flag: flagOf(o),
        canExclude: true,
        onClick: () => {
          setChoice(toggleIncluded(choice, o.value));
        },
        onExclude: () => {
          setChoice(toggleExcluded(choice, o.value));
        }
      }
    )))));
    return /* @__PURE__ */ React.createElement(React.Fragment, null, host ? PluginApi.ReactDOM.createPortal(list, host) : null, ownTagsRow ? PluginApi.ReactDOM.createPortal(
      ownTags.map((label, index) => /* @__PURE__ */ React.createElement(
        LanguageTag,
        {
          key: index,
          label,
          onRemove: () => {
            setChoice(EMPTY_SELECTION);
            setQuery("");
          }
        }
      )),
      ownTagsRow
    ) : null);
  }
  function ensureFilterHost() {
    const anchor = document.querySelector(".sidebar-saved-filters");
    if (!(anchor == null ? void 0 : anchor.parentNode)) {
      filterHost = null;
      return null;
    }
    if (!filterHost) {
      filterHost = document.createElement("div");
      filterHost.className = FILTER_HOST_CLASS;
    }
    if (filterHost.parentNode !== anchor.parentNode || anchor.nextElementSibling !== filterHost) {
      anchor.parentNode.insertBefore(filterHost, anchor.nextElementSibling);
    }
    return filterHost;
  }
  function SidebarLanguageFilter(props) {
    const intl = PluginApi.libraries.Intl.useIntl();
    const history = PluginApi.libraries.ReactRouterDOM.useHistory();
    const openState = React.useState(() => {
      const state = history.location.state;
      const stored = state ? state[SECTION_STATE_KEY] : void 0;
      return typeof stored === "boolean" ? stored : false;
    });
    const open = openState[0];
    const setOpen = openState[1];
    const queryState = React.useState("");
    const query = queryState[0];
    const setQuery = queryState[1];
    const searchRef = React.useRef(null);
    const bump = React.useState(0)[1];
    const host = ensureFilterHost();
    const selection = readLanguageFilter(props.filter);
    const criterion = languageCriterionOf(props.filter);
    const tagLabelsFor = criterion ? tagLabels(intl, criterion) : null;
    React.useLayoutEffect(() => {
      adoptLanguageCriterion(props.filter);
      if (tagLabelsFor) relabelTags(tagLabelsFor);
      if (ensureFilterHost() !== host) {
        bump((v) => v + 1);
      }
    });
    if (!host) return null;
    const Bootstrap = PluginApi.libraries.Bootstrap;
    if (!Bootstrap) {
      console.error(
        "[mangaTools] react-bootstrap not available, cannot draw the language filter"
      );
      return null;
    }
    const Solid = PluginApi.libraries.FontAwesomeSolid || {};
    const Icon = PluginApi.components.Icon;
    function update(next) {
      applyLanguage(props.filter, history, next);
      if (!isTouchDevice() && searchRef.current) {
        searchRef.current.focus();
      }
    }
    function toggleInclude(code) {
      update(toggleIncluded(selection, code));
    }
    function toggleExclude(code) {
      update(toggleExcluded(selection, code));
    }
    function setModifier(modifier) {
      update(withModifier(selection, modifier));
    }
    function clearModifier() {
      update(withoutModifier(selection));
    }
    const options = visibleOptions(intl, selection);
    const selectable = selectableOptions(selection, options);
    const chosen = selectable.filter(
      (o) => selection.included.indexOf(o.value) !== -1
    );
    const excludedChosen = selectable.filter(
      (o) => selection.excluded.indexOf(o.value) !== -1
    );
    const candidates = selectable.filter(
      (o) => selection.included.indexOf(o.value) === -1 && selection.excluded.indexOf(o.value) === -1 && matchesQuery(o, query)
    );
    function toggleOpen() {
      const next = !open;
      setOpen(next);
      history.replace(
        Object.assign({}, history.location, {
          state: Object.assign({}, history.location.state, {
            [SECTION_STATE_KEY]: next
          })
        })
      );
    }
    const showModifiers = isEmptySelection(selection);
    const chosenItems = [];
    if (selection.modifier) {
      chosenItems.push(
        /* @__PURE__ */ React.createElement("li", { className: "selected-object modifier-object", key: "modifier" }, /* @__PURE__ */ React.createElement("a", { tabIndex: 0, onClick: clearModifier }, /* @__PURE__ */ React.createElement("div", { className: "label-group" }, /* @__PURE__ */ React.createElement(Icon, { className: "fa-fw include-button", icon: Solid.faCheckCircle }), /* @__PURE__ */ React.createElement("span", { className: "TruncatedText inline selected-object-label" }, "(" + message(
          intl,
          "criterion_modifier_values." + selection.modifier,
          selection.modifier === "any" ? "Any" : "None"
        ) + ")"))))
      );
    }
    chosen.forEach((o) => {
      chosenItems.push(
        /* @__PURE__ */ React.createElement(
          LanguageRow,
          {
            variant: "sidebar",
            key: "in-" + o.value,
            label: o.label,
            flag: flagOf(o),
            state: "included",
            onClick: () => {
              toggleInclude(o.value);
            }
          }
        )
      );
    });
    const section = /* @__PURE__ */ React.createElement("div", { className: "sidebar-section sidebar-list-filter" }, /* @__PURE__ */ React.createElement("div", { className: "collapse-header" }, /* @__PURE__ */ React.createElement(
      Bootstrap.Button,
      {
        onClick: toggleOpen,
        className: "minimal collapse-button"
      },
      /* @__PURE__ */ React.createElement(
        Icon,
        {
          icon: open ? Solid.faChevronDown : Solid.faChevronRight,
          fixedWidth: true
        }
      ),
      /* @__PURE__ */ React.createElement("span", null, fieldLabel(intl))
    )), chosenItems.length ? /* @__PURE__ */ React.createElement("ul", { className: "selected-list" }, chosenItems) : null, excludedChosen.length ? /* @__PURE__ */ React.createElement("ul", { className: "selected-list excluded-list" }, excludedChosen.map((o) => /* @__PURE__ */ React.createElement(
      LanguageRow,
      {
        variant: "sidebar",
        key: "ex-" + o.value,
        label: o.label,
        flag: flagOf(o),
        state: "excluded",
        onClick: () => {
          toggleExclude(o.value);
        }
      }
    ))) : null, /* @__PURE__ */ React.createElement(Bootstrap.Collapse, { in: open, mountOnEnter: true, unmountOnExit: true }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "queryable-candidate-list" }, /* @__PURE__ */ React.createElement("div", { className: "clearable-input-group" }, /* @__PURE__ */ React.createElement(
      "input",
      {
        ref: searchRef,
        className: "clearable-text-field form-control",
        value: query,
        placeholder: message(intl, "actions.search", "Search") + "\u2026",
        onChange: (e) => {
          setQuery(e.target.value);
        },
        onKeyDown: (e) => {
          if (e.key !== "Enter" || candidates.length !== 1) return;
          toggleInclude(candidates[0].value);
          setQuery("");
        }
      }
    ), query ? /* @__PURE__ */ React.createElement(
      Bootstrap.Button,
      {
        variant: "secondary",
        className: "clearable-text-field-clear",
        title: message(intl, "actions.clear", "Clear"),
        onClick: () => {
          setQuery("");
        }
      },
      /* @__PURE__ */ React.createElement(Icon, { icon: Solid.faTimes })
    ) : null), /* @__PURE__ */ React.createElement("ul", null, showModifiers ? /* @__PURE__ */ React.createElement(
      LanguageRow,
      {
        variant: "sidebar",
        label: "(" + message(intl, "criterion_modifier_values.any", "Any") + ")",
        state: "candidate",
        modifier: true,
        canExclude: false,
        onClick: () => {
          setModifier("any");
        }
      }
    ) : null, showModifiers ? /* @__PURE__ */ React.createElement(
      LanguageRow,
      {
        variant: "sidebar",
        label: "(" + message(intl, "criterion_modifier_values.none", "None") + ")",
        state: "candidate",
        modifier: true,
        canExclude: false,
        onClick: () => {
          setModifier("none");
        }
      }
    ) : null, candidates.map((o) => /* @__PURE__ */ React.createElement(
      LanguageRow,
      {
        variant: "sidebar",
        key: o.value,
        label: o.label,
        flag: flagOf(o),
        state: "candidate",
        canExclude: true,
        onClick: () => {
          toggleInclude(o.value);
          setQuery("");
        },
        onExclude: () => {
          toggleExclude(o.value);
          setQuery("");
        }
      }
    )))))));
    return PluginApi.ReactDOM.createPortal(section, host);
  }

  // plugins/mangaTools/src/mangaTools.tsx
  var PluginApi2 = requirePluginApi();
  var React2 = PluginApi2.React;
  var FIELD_NAME = NS.FIELD_NAME;
  var CENSORSHIP_FIELD_NAME = NS.CENSORSHIP_FIELD_NAME;
  var FIELD_KEY = FIELD_NAME.toLowerCase();
  var CENSORSHIP_KEY = CENSORSHIP_FIELD_NAME.toLowerCase();
  var PLUGIN_ID = "mangaTools";
  var EDIT_ANCHOR = '.form-group[data-field="studio_id"]';
  var BULK_ANCHOR = '[data-field="studio"]';
  var REFRESH_MS = 6e4;
  function originalFrom(args) {
    return args[args.length - 1];
  }
  var firedOnce = {};
  function noteFired(target) {
    if (firedOnce[target]) return;
    firedOnce[target] = true;
    console.info("[mangaTools] patch active: " + target);
  }
  var store = /* @__PURE__ */ new Map();
  var listeners = /* @__PURE__ */ new Set();
  var inFlight = null;
  var started = false;
  var lastLoggedSize = -1;
  var currentPath = window.location.pathname || "";
  function emit() {
    listeners.forEach((fn) => {
      fn();
    });
  }
  function subscribe(fn) {
    listeners.add(fn);
    return () => {
      listeners.delete(fn);
    };
  }
  function useGlobalVersion() {
    const state = React2.useState(0);
    const version = state[0];
    const setVersion = state[1];
    React2.useEffect(
      () => subscribe(() => {
        setVersion((v) => v + 1);
      }),
      []
    );
    return version;
  }
  function isGalleryContext() {
    return currentPath.indexOf("/galleries") === 0;
  }
  function currentGalleryId() {
    const m = /^\/galleries\/(\d+)(?:\/|$)/.exec(currentPath);
    return m ? m[1] : "";
  }
  function pickLanguage(customFields) {
    return NS.pickField(customFields, FIELD_NAME);
  }
  function setLanguage(customFields, code) {
    return NS.setField(customFields, FIELD_NAME, code);
  }
  function censorshipOf(customFields) {
    return NS.normalizeCensorship(
      NS.pickField(customFields, CENSORSHIP_FIELD_NAME)
    );
  }
  function storedCensorship(galleryId) {
    return censorshipOf(store.get(String(galleryId)));
  }
  function isOwnField(key) {
    const k = key.toLowerCase();
    return k === FIELD_KEY || k === CENSORSHIP_KEY;
  }
  var QUERIES = {};
  function getQuery(field) {
    var _a;
    if (QUERIES[field]) return QUERIES[field];
    const Apollo = PluginApi2.libraries.Apollo;
    const gql = (Apollo == null ? void 0 : Apollo.gql) || ((_a = PluginApi2.GQL) == null ? void 0 : _a.gql);
    if (!gql) {
      console.error("[mangaTools] gql not available, cannot build the query");
      return null;
    }
    QUERIES[field] = gql(
      [
        "query MangaToolsMap {",
        "  findGalleries(",
        "    gallery_filter: {",
        '      custom_fields: [{ field: "' + field + '", modifier: NOT_NULL }]',
        "    }",
        "    filter: { per_page: -1 }",
        "  ) {",
        "    count",
        "    galleries {",
        "      id",
        "      custom_fields",
        "    }",
        "  }",
        "}"
      ].join("\n")
    );
    return QUERIES[field];
  }
  function refresh() {
    if (inFlight) return inFlight;
    const fields = [FIELD_NAME, CENSORSHIP_FIELD_NAME];
    const queries = fields.map(getQuery);
    if (queries.some((q) => !q)) return Promise.resolve();
    let client;
    try {
      client = PluginApi2.utils.StashService.getClient();
    } catch (e) {
      console.error("[mangaTools] failed to get the Apollo client:", e);
      return Promise.resolve();
    }
    inFlight = Promise.all(
      queries.map(
        (query) => client.query({ query, fetchPolicy: "network-only" })
      )
    ).then((results) => {
      const next = /* @__PURE__ */ new Map();
      results.forEach((res) => {
        const data = res == null ? void 0 : res.data;
        const result = data ? data.findGalleries : void 0;
        const galleries = (result == null ? void 0 : result.galleries) || [];
        galleries.forEach((g) => {
          if (g.custom_fields) next.set(String(g.id), g.custom_fields);
        });
      });
      store = next;
      emit();
      if (next.size !== lastLoggedSize) {
        lastLoggedSize = next.size;
        console.info(
          "[mangaTools] loaded custom fields for " + next.size + " gallery(ies)"
        );
      }
    }).catch((e) => {
      console.error(
        "[mangaTools] failed to fetch custom fields, marks will not show. Raw error:",
        e
      );
    }).then(() => {
      inFlight = null;
    });
    return inFlight;
  }
  var SETTINGS_QUERY = null;
  function getSettingsQuery() {
    var _a;
    if (SETTINGS_QUERY) return SETTINGS_QUERY;
    const Apollo = PluginApi2.libraries.Apollo;
    const gql = (Apollo == null ? void 0 : Apollo.gql) || ((_a = PluginApi2.GQL) == null ? void 0 : _a.gql);
    if (!gql) {
      console.error("[mangaTools] gql not available, cannot read settings");
      return null;
    }
    SETTINGS_QUERY = gql(
      [
        "query MangaToolsSettings {",
        "  configuration {",
        "    plugins",
        "  }",
        "}"
      ].join("\n")
    );
    return SETTINGS_QUERY;
  }
  function refreshSettings() {
    const query = getSettingsQuery();
    if (!query) return;
    let client;
    try {
      client = PluginApi2.utils.StashService.getClient();
    } catch (e) {
      console.error("[mangaTools] failed to get the Apollo client:", e);
      return;
    }
    client.query({ query, fetchPolicy: "no-cache" }).then((res) => {
      var _a;
      const data = res == null ? void 0 : res.data;
      const plugins = (_a = data == null ? void 0 : data.configuration) == null ? void 0 : _a.plugins;
      const pluginCfg = plugins == null ? void 0 : plugins[PLUGIN_ID];
      NS.enabledLanguages = NS.parseEnabledLanguages(
        pluginCfg ? pluginCfg.enabledLanguages : null
      );
      NS.showFlags = NS.parseFlag(pluginCfg ? pluginCfg.showFlags : null, true);
      NS.showCoverBadge = NS.parseFlag(
        pluginCfg ? pluginCfg.showCoverBadge : null,
        true
      );
      emit();
    }).catch((e) => {
      console.error("[mangaTools] failed to fetch plugin settings:", e);
    });
  }
  function start() {
    var _a;
    if (started) return;
    started = true;
    refresh();
    refreshSettings();
    window.setInterval(() => {
      if (document.visibilityState === "visible") refresh();
    }, REFRESH_MS);
    if ((_a = PluginApi2.Event) == null ? void 0 : _a.addEventListener) {
      PluginApi2.Event.addEventListener("stash:location", (e) => {
        var _a2, _b;
        const ev = e;
        const loc = (_b = (_a2 = ev == null ? void 0 : ev.detail) == null ? void 0 : _a2.data) == null ? void 0 : _b.location;
        currentPath = (loc == null ? void 0 : loc.pathname) || window.location.pathname || "";
        refresh();
        refreshSettings();
        emit();
      });
    }
  }
  function refreshAfterWrite() {
    const pending = inFlight;
    if (pending) {
      pending.then(() => {
        refresh();
      });
    } else {
      refresh();
    }
  }
  function useLocale() {
    return PluginApi2.libraries.Intl.useIntl().locale;
  }
  function Flag2(props) {
    return /* @__PURE__ */ React2.createElement(
      "span",
      {
        className: "fi fi-" + props.flag + (props.className ? " " + props.className : "")
      }
    );
  }
  function LanguageBadge(props) {
    useGlobalVersion();
    const locale = useLocale();
    const info = NS.describe(
      pickLanguage(store.get(String(props.galleryId))),
      locale
    );
    if (!info) return null;
    if (!info.known) {
      return /* @__PURE__ */ React2.createElement("div", { className: "manga-tools-badge is-unknown" }, info.name);
    }
    if (!NS.showFlags) {
      return /* @__PURE__ */ React2.createElement("div", { className: "manga-tools-badge is-name" }, info.name);
    }
    return /* @__PURE__ */ React2.createElement("div", { className: "manga-tools-badge", "aria-label": info.name }, /* @__PURE__ */ React2.createElement(Flag2, { flag: info.flag }));
  }
  function censorshipIcon(value) {
    const Solid = PluginApi2.libraries.FontAwesomeSolid || {};
    if (value === "censored") return Solid.faChessKnight;
    if (value === "uncensored") return Solid.faChessPawn;
    return Solid.faChessBoard;
  }
  function censorshipLabel(intl, value) {
    if (value === "censored") return t(intl, "mangaTools.censorship.censored");
    if (value === "uncensored")
      return t(intl, "mangaTools.censorship.uncensored");
    return t(intl, "mangaTools.censorship.unset");
  }
  function censorshipAction(intl, value) {
    if (value === "censored")
      return t(intl, "mangaTools.censorship.markUncensored");
    if (value === "uncensored") return t(intl, "mangaTools.censorship.clear");
    return t(intl, "mangaTools.censorship.markCensored");
  }
  function nextCensorship(value) {
    const values = NS.CENSORSHIP_VALUES;
    const i = values.indexOf(value);
    return i === -1 ? values[0] : values[i + 1] || "";
  }
  var POPOVER_ANCHOR_CLASS = "manga-tools-popover-anchor";
  var POPOVER_SLOT_CLASS = "manga-tools-popover-slot";
  var POPOVER_ROW_CLASS = "manga-tools-popovers";
  function useAfterMount() {
    const bump = React2.useState(0)[1];
    React2.useLayoutEffect(() => {
      bump(1);
    }, []);
  }
  function hasClass(el, name) {
    return !!el && (el.className || "").split(/\s+/).indexOf(name) >= 0;
  }
  function ensurePopoverSlot(galleryId) {
    const anchor = document.querySelector(
      '[data-gallery="' + galleryId + '"]'
    );
    if (!(anchor == null ? void 0 : anchor.parentNode)) return null;
    const previous = anchor.previousElementSibling;
    let row;
    if (hasClass(previous, "card-popovers") || hasClass(previous, POPOVER_ROW_CLASS)) {
      row = previous;
    } else {
      row = document.createElement("div");
      row.className = "btn-group card-popovers " + POPOVER_ROW_CLASS;
      anchor.parentNode.insertBefore(row, anchor);
    }
    let slot = null;
    for (let i = 0; i < row.children.length; i++) {
      if (hasClass(row.children[i], POPOVER_SLOT_CLASS)) {
        slot = row.children[i];
        break;
      }
    }
    if (slot) {
      if (row.lastElementChild !== slot) row.appendChild(slot);
      return slot;
    }
    slot = document.createElement("span");
    slot.className = POPOVER_SLOT_CLASS;
    row.appendChild(slot);
    return slot;
  }
  function CensorshipPopoverMark(props) {
    useGlobalVersion();
    useAfterMount();
    const Icon = PluginApi2.components.Icon;
    const intl = PluginApi2.libraries.Intl.useIntl();
    const value = storedCensorship(props.galleryId);
    const slot = value ? ensurePopoverSlot(props.galleryId) : null;
    if (!value) return null;
    return /* @__PURE__ */ React2.createElement(React2.Fragment, null, /* @__PURE__ */ React2.createElement("span", { className: POPOVER_ANCHOR_CLASS, "data-gallery": props.galleryId }), slot ? PluginApi2.ReactDOM.createPortal(
      /* @__PURE__ */ React2.createElement(
        "button",
        {
          type: "button",
          className: "minimal btn btn-primary manga-tools-mark",
          title: censorshipLabel(intl, value)
        },
        /* @__PURE__ */ React2.createElement(Icon, { icon: censorshipIcon(value) })
      ),
      slot
    ) : null);
  }
  var TOOLBAR_HOST_CLASS = "manga-tools-toolbar-host";
  var CAN_WRITE_CENSORSHIP = typeof PluginApi2.utils.StashService.useGalleryUpdate === "function";
  if (!CAN_WRITE_CENSORSHIP) {
    console.error(
      "[mangaTools] this Stash has no useGalleryUpdate, so the censorship button will not be shown. The language features are unaffected."
    );
  }
  var toolbarHost = null;
  function ensureToolbarHost() {
    const button = document.querySelector(".gallery-toolbar .organized-button");
    const anchor = (button == null ? void 0 : button.parentNode) || null;
    if (!(anchor == null ? void 0 : anchor.parentNode)) {
      toolbarHost = null;
      return null;
    }
    if (!toolbarHost) {
      toolbarHost = document.createElement("span");
      toolbarHost.className = TOOLBAR_HOST_CLASS;
    }
    if (anchor.nextElementSibling !== toolbarHost) {
      anchor.parentNode.insertBefore(toolbarHost, anchor.nextElementSibling);
    }
    return toolbarHost;
  }
  function setStoredCensorship(galleryId, value) {
    const id = String(galleryId);
    const next = new Map(store);
    next.set(id, NS.setField(next.get(id), CENSORSHIP_FIELD_NAME, value));
    store = next;
    emit();
  }
  function CensorshipToolbarButton(props) {
    useGlobalVersion();
    useAfterMount();
    const Icon = PluginApi2.components.Icon;
    const intl = PluginApi2.libraries.Intl.useIntl();
    const update = PluginApi2.utils.StashService.useGalleryUpdate();
    const busyState = React2.useState(false);
    const busy = busyState[0];
    const setBusy = busyState[1];
    const host = ensureToolbarHost();
    if (!host) return null;
    const mark = props.value;
    const next = nextCensorship(mark);
    const onClick = () => {
      const input = { id: props.galleryId };
      if (next) {
        input.custom_fields = { partial: { [CENSORSHIP_FIELD_NAME]: next } };
      } else {
        input.custom_fields = { remove: [props.fieldKey] };
      }
      setBusy(true);
      update[0]({ variables: { input } }).then(
        () => {
          setBusy(false);
          setStoredCensorship(props.galleryId, next);
        },
        (e) => {
          setBusy(false);
          console.error("[mangaTools] failed to write the censorship mark:", e);
        }
      );
    };
    return PluginApi2.ReactDOM.createPortal(
      /* @__PURE__ */ React2.createElement(
        "button",
        {
          type: "button",
          title: censorshipAction(intl, mark),
          className: "minimal manga-tools-censorship btn btn-secondary" + (mark ? " is-" + mark : " is-unmarked"),
          disabled: busy,
          onClick
        },
        /* @__PURE__ */ React2.createElement(Icon, { icon: censorshipIcon(mark) })
      ),
      host
    );
  }
  var SELECT = null;
  function resolveSelect() {
    if (SELECT) return SELECT;
    const RS = PluginApi2.libraries.ReactSelect;
    if (!RS) {
      console.error("[mangaTools] react-select not available");
      return null;
    }
    SELECT = RS.default || RS.Select || RS;
    return SELECT;
  }
  function formatLanguageOption(option) {
    return /* @__PURE__ */ React2.createElement("span", { className: "manga-tools-option" }, NS.showFlags && option.flag ? /* @__PURE__ */ React2.createElement(Flag2, { flag: option.flag, className: "manga-tools-flag" }) : null, /* @__PURE__ */ React2.createElement("span", null, option.label));
  }
  function readNativeFieldClasses(anchorSelector) {
    const anchor = document.querySelector(anchorSelector);
    if (!anchor) return null;
    const label = anchor.querySelector("label");
    const control = label == null ? void 0 : label.nextElementSibling;
    if (!label || !control) return null;
    return {
      group: anchor.className,
      label: label.className,
      control: control.className
    };
  }
  function LanguageRow2(props) {
    useGlobalVersion();
    const intl = PluginApi2.libraries.Intl.useIntl();
    const Select = resolveSelect();
    const host = isGalleryContext() ? ensureFieldHost() : null;
    const bump = React2.useState(0)[1];
    React2.useLayoutEffect(() => {
      if (isGalleryContext() && ensureFieldHost() !== host) {
        bump((v) => v + 1);
      }
    });
    if (!isGalleryContext() || !Select || !host) return null;
    const current = NS.describe(props.value, intl.locale);
    let options = NS.languageOptions(intl.locale).filter(
      (o) => {
        return !NS.enabledLanguages || NS.enabledLanguages.has(o.value);
      }
    );
    if (current && !current.known) {
      options = [
        { value: current.code, label: current.name, flag: null },
        ...options
      ];
    }
    const selected = current ? { value: current.code, label: current.name, flag: current.flag } : null;
    const cls = readNativeFieldClasses(EDIT_ANCHOR) || {
      group: "form-group row",
      label: "form-label col-form-label col-sm-3",
      control: "col-sm-9"
    };
    const field = (
      // Plain div/label carrying the copied class names, rather than
      // Form.Group/Form.Label/Col: those components regenerate the width classes
      // from their own defaults, which is what broke the alignment before.
      /* @__PURE__ */ React2.createElement("div", { className: cls.group, "data-field": "manga_tools_language" }, /* @__PURE__ */ React2.createElement("label", { className: cls.label, htmlFor: "manga_tools_language" }, fieldLabel2(intl)), /* @__PURE__ */ React2.createElement("div", { className: cls.control }, /* @__PURE__ */ React2.createElement(
        Select,
        {
          className: "manga-tools-select",
          classNamePrefix: "react-select",
          inputId: "manga_tools_language",
          isClearable: true,
          isSearchable: false,
          placeholder: t(intl, "mangaTools.select.placeholder"),
          value: selected,
          options,
          components: { IndicatorSeparator: () => null },
          formatOptionLabel: formatLanguageOption,
          onChange: (opt) => {
            props.onChange(opt ? opt.value : "");
          }
        }
      )))
    );
    return PluginApi2.ReactDOM.createPortal(field, host);
  }
  function BooleanSetting(props) {
    const Bootstrap = PluginApi2.libraries.Bootstrap;
    if (!Bootstrap) {
      console.error(
        "[mangaTools] react-bootstrap not available, cannot render the settings switches"
      );
      return null;
    }
    return /* @__PURE__ */ React2.createElement("div", { className: "setting" }, /* @__PURE__ */ React2.createElement("div", null, /* @__PURE__ */ React2.createElement("h3", null, props.heading), /* @__PURE__ */ React2.createElement("div", { className: "sub-heading" }, props.subHeading)), /* @__PURE__ */ React2.createElement("div", null, /* @__PURE__ */ React2.createElement(
      Bootstrap.Form.Switch,
      {
        id: props.id,
        checked: props.checked,
        onChange: () => {
          props.onChange(!props.checked);
        }
      }
    )));
  }
  function MangaToolsSettings(props) {
    useGlobalVersion();
    const intl = PluginApi2.libraries.Intl.useIntl();
    const Select = resolveSelect();
    const savePlugin = PluginApi2.utils.StashService.useConfigurePlugin()[0];
    function persist() {
      savePlugin({
        variables: {
          plugin_id: props.pluginID,
          input: {
            enabledLanguages: NS.enabledLanguages ? NS.serializeEnabledLanguages(NS.enabledLanguages) : "",
            showFlags: NS.showFlags,
            showCoverBadge: NS.showCoverBadge
          }
        }
      }).catch((e) => {
        console.error("[mangaTools] failed to save plugin settings:", e);
      });
    }
    const options = NS.languageOptions(intl.locale);
    const enabled = NS.enabledLanguages;
    const value = enabled ? options.filter((o) => enabled == null ? void 0 : enabled.has(o.value)) : [];
    if (!Select) return null;
    return /* @__PURE__ */ React2.createElement(React2.Fragment, null, /* @__PURE__ */ React2.createElement("div", { className: "setting manga-tools-settings" }, /* @__PURE__ */ React2.createElement("div", { className: "manga-tools-settings-block" }, /* @__PURE__ */ React2.createElement("h3", null, t(intl, "mangaTools.settings.enabledLanguages.heading")), /* @__PURE__ */ React2.createElement("div", { className: "sub-heading" }, t(intl, "mangaTools.settings.enabledLanguages.description")), /* @__PURE__ */ React2.createElement("div", { className: "manga-tools-settings-control" }, /* @__PURE__ */ React2.createElement(
      Select,
      {
        className: "manga-tools-settings-select",
        classNamePrefix: "react-select",
        isMulti: true,
        isClearable: true,
        menuPlacement: "auto",
        placeholder: t(
          intl,
          "mangaTools.settings.enabledLanguages.placeholder"
        ),
        value,
        options,
        formatOptionLabel: formatLanguageOption,
        components: { IndicatorSeparator: () => null },
        onChange: (selected) => {
          const codes = (selected || []).map((o) => o.value);
          NS.enabledLanguages = NS.parseEnabledLanguages(
            NS.serializeEnabledLanguages(codes)
          );
          emit();
          persist();
        }
      }
    )))), /* @__PURE__ */ React2.createElement(
      BooleanSetting,
      {
        id: "mangaTools-showFlags",
        heading: t(intl, "mangaTools.settings.showFlags.heading"),
        subHeading: t(intl, "mangaTools.settings.showFlags.description"),
        checked: NS.showFlags,
        onChange: (next) => {
          NS.showFlags = next;
          emit();
          persist();
        }
      }
    ), /* @__PURE__ */ React2.createElement(
      BooleanSetting,
      {
        id: "mangaTools-showCoverBadge",
        heading: t(intl, "mangaTools.settings.showCoverBadge.heading"),
        subHeading: t(intl, "mangaTools.settings.showCoverBadge.description"),
        checked: NS.showCoverBadge,
        onChange: (next) => {
          NS.showCoverBadge = next;
          emit();
          persist();
        }
      }
    ));
  }
  var bulkPending = null;
  var selectedGalleryIds = [];
  function captureSelection(selectedIds) {
    const next = [];
    if (selectedIds && typeof selectedIds.forEach === "function") {
      selectedIds.forEach((id) => {
        next.push(String(id));
      });
    }
    const unchanged = next.length === selectedGalleryIds.length && next.every((id, i) => id === selectedGalleryIds[i]);
    if (!unchanged) selectedGalleryIds = next;
  }
  function selectedLanguageAggregate() {
    if (!selectedGalleryIds.length) return null;
    const first = pickLanguage(store.get(selectedGalleryIds[0]));
    for (let i = 1; i < selectedGalleryIds.length; i++) {
      if (pickLanguage(store.get(selectedGalleryIds[i])) !== first) return null;
    }
    return first || null;
  }
  var bulkLinkInstalled = false;
  function isGalleryBulkUpdate(query) {
    var _a;
    const defs = query ? query.definitions : null;
    if (!(defs == null ? void 0 : defs.length)) return false;
    const op = defs[0];
    if ((op == null ? void 0 : op.kind) !== "OperationDefinition") return false;
    const selections = (_a = op.selectionSet) == null ? void 0 : _a.selections;
    if (!(selections == null ? void 0 : selections.length)) return false;
    const first = selections[0];
    return !!((first == null ? void 0 : first.name) && first.name.value === "bulkGalleryUpdate");
  }
  function applyPendingLanguage(operation) {
    if ((bulkPending == null ? void 0 : bulkPending.kind) !== "set") return false;
    if (!isGalleryContext()) return false;
    if (!isGalleryBulkUpdate(operation.query)) return false;
    const input = operation.variables ? operation.variables.input : void 0;
    if (!input || !Array.isArray(input.ids)) return false;
    const fields = { partial: { [FIELD_NAME]: bulkPending.value } };
    operation.variables = Object.assign({}, operation.variables, {
      input: Object.assign({}, input, {
        custom_fields: Object.assign(
          {},
          input.custom_fields,
          fields
        )
      })
    });
    return true;
  }
  function installBulkLink() {
    if (bulkLinkInstalled) return;
    const Apollo = PluginApi2.libraries.Apollo;
    let client;
    try {
      client = PluginApi2.utils.StashService.getClient();
    } catch (e) {
      console.error("[mangaTools] failed to get the Apollo client:", e);
      return;
    }
    if (!(Apollo == null ? void 0 : Apollo.ApolloLink) || typeof client.setLink !== "function" || !client.link) {
      console.error(
        "[mangaTools] ApolloLink/setLink unavailable \u2014 languages cannot be set from the bulk edit dialog"
      );
      return;
    }
    const previous = client.link;
    client.setLink(
      Apollo.ApolloLink.from([
        new Apollo.ApolloLink((operation, forward) => {
          if (!applyPendingLanguage(operation)) {
            return forward(operation);
          }
          console.info(
            "[mangaTools] bulk update: sending the language with the dialog's own update"
          );
          return forward(operation).map((result) => {
            bulkPending = null;
            refreshAfterWrite();
            emit();
            return result;
          });
        }),
        previous
      ])
    );
    bulkLinkInstalled = true;
  }
  function BulkLanguageRow() {
    useGlobalVersion();
    const intl = PluginApi2.libraries.Intl.useIntl();
    const Select = resolveSelect();
    const host = isGalleryContext() ? ensureBulkFieldHost() : null;
    const bump = React2.useState(0)[1];
    React2.useLayoutEffect(() => {
      if (isGalleryContext()) {
        installBulkLink();
        if (ensureBulkFieldHost() !== host) {
          bump((v) => v + 1);
        }
      }
    });
    React2.useEffect(
      () => () => {
        if (!document.querySelector(BULK_ANCHOR)) {
          bulkPending = null;
        }
      },
      []
    );
    if (!isGalleryContext() || !Select || !host) return null;
    let options = NS.languageOptions(intl.locale).filter(
      (o) => !NS.enabledLanguages || NS.enabledLanguages.has(o.value)
    );
    const pending = bulkPending;
    const shown = pending && pending.kind === "set" ? pending.value : pending ? "" : selectedLanguageAggregate() || "";
    const current = shown ? NS.describe(shown, intl.locale) : null;
    const currentCode = current ? current.code : "";
    if (current && !options.some((o) => o.value === currentCode)) {
      options = [
        { value: current.code, label: current.name, flag: current.flag },
        ...options
      ];
    }
    const selected = current ? { value: current.code, label: current.name, flag: current.flag } : null;
    const cls = readNativeFieldClasses(BULK_ANCHOR) || {
      group: "row",
      label: "col-form-label col-3",
      control: "col-9"
    };
    const field = /* @__PURE__ */ React2.createElement("div", { className: cls.group, "data-field": "manga_tools_language" }, /* @__PURE__ */ React2.createElement("label", { className: cls.label, htmlFor: "manga_tools_language" }, fieldLabel2(intl)), /* @__PURE__ */ React2.createElement("div", { className: cls.control }, /* @__PURE__ */ React2.createElement(
      Select,
      {
        className: "manga-tools-select",
        classNamePrefix: "react-select",
        inputId: "manga_tools_language",
        isClearable: true,
        isSearchable: false,
        menuPortalTarget: document.body,
        placeholder: t(intl, "mangaTools.select.placeholder"),
        value: selected,
        options,
        formatOptionLabel: formatLanguageOption,
        components: { IndicatorSeparator: () => null },
        onChange: (opt) => {
          bulkPending = opt ? { kind: "set", value: opt.value } : { kind: "cleared" };
          emit();
        }
      }
    )));
    return PluginApi2.ReactDOM.createPortal(field, host);
  }
  PluginApi2.patch.instead("GalleryCard.Overlays", (...args) => {
    var _a;
    const props = args[0];
    const Original = originalFrom(args);
    noteFired("GalleryCard.Overlays");
    const id = (_a = props.gallery) == null ? void 0 : _a.id;
    const value = id ? pickLanguage(store.get(String(id))) : "";
    if (!value || !NS.showCoverBadge) return /* @__PURE__ */ React2.createElement(Original, { ...props });
    return /* @__PURE__ */ React2.createElement(React2.Fragment, null, /* @__PURE__ */ React2.createElement(Original, { ...props }), /* @__PURE__ */ React2.createElement(LanguageBadge, { galleryId: id }));
  });
  PluginApi2.patch.instead("GalleryCard.Popovers", (...args) => {
    var _a;
    const props = args[0];
    const Original = originalFrom(args);
    noteFired("GalleryCard.Popovers");
    const id = (_a = props.gallery) == null ? void 0 : _a.id;
    if (!id || !storedCensorship(String(id))) return /* @__PURE__ */ React2.createElement(Original, { ...props });
    return /* @__PURE__ */ React2.createElement(React2.Fragment, null, /* @__PURE__ */ React2.createElement(Original, { ...props }), /* @__PURE__ */ React2.createElement(CensorshipPopoverMark, { galleryId: String(id) }));
  });
  PluginApi2.patch.instead("CustomFieldsInput", (...args) => {
    const props = args[0];
    const Original = originalFrom(args);
    noteFired("CustomFieldsInput");
    return /* @__PURE__ */ React2.createElement(React2.Fragment, null, /* @__PURE__ */ React2.createElement(
      LanguageRow2,
      {
        value: pickLanguage(props.values),
        onChange: (code) => {
          if (props.onChange) {
            props.onChange(setLanguage(props.values, code));
          }
        }
      }
    ), /* @__PURE__ */ React2.createElement(Original, { ...props }));
  });
  PluginApi2.patch.instead("CustomFieldInput", (...args) => {
    const props = args[0];
    const Original = originalFrom(args);
    noteFired("CustomFieldInput");
    const isLanguageField = !!props.field && String(props.field).toLowerCase() === FIELD_KEY;
    if (!props.isNew && isLanguageField) {
      return null;
    }
    return /* @__PURE__ */ React2.createElement(Original, { ...props });
  });
  var DETAIL_HOST_CLASS = "manga-tools-detail-host";
  var detailHost = null;
  function ensureDetailHost() {
    const panel = document.querySelector(".gallery-details");
    if (!panel) {
      detailHost = null;
      return null;
    }
    if (!detailHost) {
      detailHost = document.createElement("div");
      detailHost.className = DETAIL_HOST_CLASS;
    }
    if (detailHost.parentNode !== panel || panel.lastElementChild !== detailHost) {
      panel.appendChild(detailHost);
    }
    return detailHost;
  }
  var FIELD_HOST_CLASS = "manga-tools-field-host";
  var fieldHosts = {
    edit: null,
    bulk: null
  };
  function ensureHostAfter(anchorSelector, key) {
    const anchor = document.querySelector(anchorSelector);
    if (!(anchor == null ? void 0 : anchor.parentNode)) {
      fieldHosts[key] = null;
      return null;
    }
    let host = fieldHosts[key];
    if (!host) {
      host = document.createElement("div");
      host.className = FIELD_HOST_CLASS;
      fieldHosts[key] = host;
    }
    if (host.parentNode !== anchor.parentNode || anchor.nextElementSibling !== host) {
      anchor.parentNode.insertBefore(host, anchor.nextElementSibling);
    }
    return host;
  }
  function ensureFieldHost() {
    return ensureHostAfter(EDIT_ANCHOR, "edit");
  }
  function ensureBulkFieldHost() {
    return ensureHostAfter(BULK_ANCHOR, "bulk");
  }
  function fieldLabel2(intl) {
    return intl.formatMessage({
      id: "config.ui.language.heading",
      defaultMessage: "Language"
    });
  }
  function DetailLanguageRow(props) {
    useGlobalVersion();
    const intl = PluginApi2.libraries.Intl.useIntl();
    const info = NS.describe(props.value, intl.locale);
    if (!info) return null;
    const host = ensureDetailHost();
    if (!host) return null;
    const showFlag = NS.showFlags && !!info.flag;
    return PluginApi2.ReactDOM.createPortal(
      /* @__PURE__ */ React2.createElement("h6", { className: "manga-tools-detail" }, fieldLabel2(intl) + ": ", showFlag ? /* @__PURE__ */ React2.createElement(Flag2, { flag: info.flag, className: "manga-tools-flag" }) : null, showFlag ? " " : null, info.name),
      host
    );
  }
  PluginApi2.patch.instead("CustomFields", (...args) => {
    const props = args[0];
    const Original = originalFrom(args);
    noteFired("CustomFields");
    const values = props.values;
    if (!values || typeof values !== "object") return /* @__PURE__ */ React2.createElement(Original, { ...props });
    const rest = Object.assign({}, values);
    let languageKey = null;
    let censorshipKey = null;
    Object.keys(values).forEach((k) => {
      if (!isOwnField(k)) return;
      if (k.toLowerCase() === FIELD_KEY) languageKey = k;
      else censorshipKey = k;
      delete rest[k];
    });
    const lifted = languageKey !== null || censorshipKey !== null;
    const galleryId = CAN_WRITE_CENSORSHIP ? currentGalleryId() : "";
    if (!lifted && !galleryId) return /* @__PURE__ */ React2.createElement(Original, { ...props });
    return /* @__PURE__ */ React2.createElement(React2.Fragment, null, /* @__PURE__ */ React2.createElement(
      Original,
      {
        ...lifted ? Object.assign({}, props, { values: rest }) : props
      }
    ), languageKey === null ? null : /* @__PURE__ */ React2.createElement(DetailLanguageRow, { value: values[languageKey] }), galleryId ? /* @__PURE__ */ React2.createElement(
      CensorshipToolbarButton,
      {
        galleryId,
        value: censorshipOf(values),
        fieldKey: censorshipKey || CENSORSHIP_FIELD_NAME
      }
    ) : null);
  });
  PluginApi2.patch.instead("PluginSettings", (...args) => {
    const props = args[0];
    const Original = originalFrom(args);
    noteFired("PluginSettings");
    if (props.pluginID === PLUGIN_ID) {
      return /* @__PURE__ */ React2.createElement(MangaToolsSettings, { pluginID: props.pluginID });
    }
    return /* @__PURE__ */ React2.createElement(Original, { ...props });
  });
  PluginApi2.patch.before("GalleryList", (...args) => {
    const props = args[0];
    noteFired("GalleryList");
    captureSelection(props ? props.selectedIds : null);
    return args;
  });
  PluginApi2.patch.instead("GalleryList", (...args) => {
    const props = args[0];
    const Original = originalFrom(args);
    noteFired("GalleryList.filter");
    if (props.filter) registerLanguageCriterionOption(props.filter);
    return /* @__PURE__ */ React2.createElement(React2.Fragment, null, /* @__PURE__ */ React2.createElement(SidebarLanguageFilter, { filter: props.filter }), /* @__PURE__ */ React2.createElement(DialogLanguageFilter, { filter: props.filter }), /* @__PURE__ */ React2.createElement(Original, { ...props }));
  });
  PluginApi2.patch.instead("RatingSystem", (...args) => {
    const props = args[0];
    const Original = originalFrom(args);
    noteFired("RatingSystem");
    return /* @__PURE__ */ React2.createElement(React2.Fragment, null, /* @__PURE__ */ React2.createElement(Original, { ...props }), /* @__PURE__ */ React2.createElement(BulkLanguageRow, null));
  });
  start();
})();
